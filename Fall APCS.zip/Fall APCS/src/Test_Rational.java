
public class Test_Rational {
	public static void main(String[] args) {
		Rational so = new Rational (3, 5);
		so.plus(so);
		
		int num = 1, denom = 2, value = 3;
		
		Rational a = new Rational();
		Rational r = new Rational(num, denom);
		int n = value;
		
	}
}
