public class Q19_MC_test {
 
  public static void main(String[] args) {
    TwentyFourFiveSixPaperThing obj = new TwentyFourFiveSixPaperThing();
    obj.resetTwentyFourFiveSixPaperThing(12,30,42);
    obj.display(obj);

 }
}
