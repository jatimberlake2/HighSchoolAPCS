
public class ElevenPaperThing {

	public static void main(String[] args) {
		int a = 1; int b = 2;  int c = 0;
	if ((a < b) || !((c == a * b) && (c < a)))
		System.out.println("Fudge");
	else
		System.out.println("Cake");
	}

}