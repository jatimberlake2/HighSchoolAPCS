public class Rational 
{

	private int myNum;		//numerator
	private int myDenom;	//denominator
	
	//constructors
	/* default constructor */
	Rational()
	{
		myNum = 0;
		myDenom = 0;
	
	}
	
	/*Constructs a Rational with specified numerator and denominator*/
	Rational(int numer, int denom)
	{
		myNum = numer;
		myDenom = denom;
		
	}
	
	//accessors
	
	/* Returns numerator. */
	int numerator()
	{
		return myNum;
	}
	
	/* Returns denominator. */
	int denominator()
	{
		return myDenom;
	}
	
	//arithmetic operations
	/* Returns (this + r).
	 * Leaves this unchanged. */
	
	public Rational plus(Rational r)
	{
	fixSigns();
	int denom = myDenom * r.myDenom;
	int num = myNum * r.myDenom + r.myNum * myDenom;
	//
	
	Rational rat = new Rational (num, denom);
	rat.reduce();
	return rat;
	
	}
	
	//Similarly for times, minus, divide
		//...
	/*Ensures myDenom > 0. */
	
	private void fixSigns()
	{
		if (myDenom < 0)
			myDenom = -1 * myDenom;
			System.out.println(myDenom);
	}
	
	/* Ensures lowest terms. */
	
	private void reduce()
	{
		
	}
}
