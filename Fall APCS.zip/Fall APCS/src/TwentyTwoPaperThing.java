
public class TwentyTwoPaperThing {

	public static void main(String[] args) {
		
		int k = 666;
		int newNum = 0, temp;
		int num = k;				//k is some predefined integer value >= 0
		
		while (num > 10)
		{
			temp = num%10;
			num /= 10;
			newNum = newNum * 10 + temp;
		}
		System.out.println(newNum);

	}

}
