// A bubble sort for Strings. 
class SortString { 
static String names[] = { 
"Tim", "Bill", "Sue", "Jim"
};

public static void main(String args[]) { 
	for(int j = 0; j < names.length; j++) { 
		for(int i = j + 1; i < names.length; i++) { 
			if(names[i].compareTo(names[j]) < 0) { 
				String t = names[j]; 
				names[j] = names[i]; 
				names[i] = t; 
				} 
			} 
		System.out.println(names[j]); 
		}
	}
}