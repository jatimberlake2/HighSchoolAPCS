public class FivePaperThing {
	public static void main(String[] args) {
		int stuff = - 4 + 8 + 2 + 3 * 12 / 7;
		System.out.println(stuff);
	}
}
