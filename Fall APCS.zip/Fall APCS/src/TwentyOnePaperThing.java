
public class TwentyOnePaperThing {
	public static void main(String[] args) {
		
		for (int i = 1; i <= 6; i++){
			for (int k = 1; k <= 6; k++)
				if (k == i)
					System.out.print(2*k);
				else
					System.out.print("-");
			System.out.println();
		}
		
		for (int i = 1; i <= 6; i++) {
			for (int k = 1; k <= i - 1; k++)
				System.out.print("-");
			System.out.print(2*i);
			for (int k = 1; k <= 6 - i; k++)
				System.out.print("-");
			System.out.println();
		}
		
		for (int i = 1; i <= 6; i++) {
			for (int k = 1; k <= i - 1; k++)
				System.out.print("-");
			System.out.print(2*i);
			for (int k = i + 1; k <= 6; k++)
				System.out.print("-");
			System.out.println();
		}
	}
}
