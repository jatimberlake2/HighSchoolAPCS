
public class TwelvePaperThing {

	public static void main(String[] args) {
		int count = 0, n = 3;
		System.out.println("Eins");
		for (count = 1; count <= n; count++)
			System.out.println(count);
		
		System.out.println();
		System.out.println("Zwei");
		count = 1;
		while (count <= n)
		{
			System.out.println(count);
			count++;
		}

	}

}
