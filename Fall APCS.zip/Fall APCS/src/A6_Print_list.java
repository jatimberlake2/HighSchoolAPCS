import java.util.*;
public class A6_Print_list {
		public static void main(String[] args) {
			Scanner derp = new Scanner(System.in);
			String [] names = {};
			int head_of_list = 1, prev = 0, current = 0; // Bill is the first name
			int [] links = {}; // shows the next place ending with -1
			boolean spacing = false;
			
			
			while (true){
				if (spacing == true)
					System.out.println();
				System.out.println("What do you want to do? (Enter a number choice.)");
				System.out.println("1. Add a name to the list");
				System.out.println("2. Remove a name from the list");
				System.out.println("3. Print the names in alphabetical order");
				System.out.println("4. Print the number in the head of the list and the numbers in the links array");
				System.out.println("5. Print the number in the head of the �removed names� list and the numbers in the links array");
				System.out.println("6. Quit");
				spacing = true;
				
				int herp = derp.nextInt();
				
				
				if (herp == 1) {
					boolean adding = true;
					while (adding) {
					System.out.println("Whose name are you adding? Or say 'quit' to quit");
				
				
				
				
				// Add a name to the list
				String nxt = derp.nextLine();
				System.out.println();

				
				String[] snames = names;
				int[] slinks = links;
				
				names = new String[names.length+1];
				links = new int[links.length+1];
			
			for (int n = 0; n < names.length-1; n++){
				names[n] = snames[n];	
				links[n] = slinks[n];
			}
		

			if (snames.length == 0)
			{
				/* empty list */
				names[0] = nxt;
				head_of_list = 0;
				links[0] = -1;
			//	print_names(names, head_of_list, links);
			}
				
				
		//System.out.println("Test names2: " + names2[0] + " names: " + names[0]);
			else
			{
				names[names.length-1] = nxt;				
				if (names[names.length-1].compareTo(names[head_of_list]) < 0)
					{
					//System.out.println(head_of_list);
					//System.out.println(nxt.compareTo(names[head_of_list]));
					
					/* if the name is first in the list */
					
					links[links.length-1]= head_of_list; 
					head_of_list = names.length-1;
					}
				
				
				else {
					
					
					/* if the name is not first in the list  */
					
						names[names.length-1]= nxt;
						prev = head_of_list;
						current = head_of_list;
				
					while (links[current] != -1 ) {
						// if the name is between Bill and Tim
						if (nxt.compareTo(names[links[current]]) < 0){
							prev = current;				
							current = links[current];
							//error
							break;
							}						
						current = links[current];
					}	
					if (links[current] == -1)
						{	
							/* if the name is after Tim */
							prev = current;
							current = -1;
						}

					links[prev] = links.length-1;
					links[links.length-1] = current;						
						
							}	
						}
					}
			
			
			
			print_names(names, head_of_list, links);
			}
			}
		}
		public static void print_names (String[] first_names, int head, int[] linked_list){
			while (head != -1){
				System.out.println(first_names[head]);
				head = linked_list[head];

								}		
				}
		}