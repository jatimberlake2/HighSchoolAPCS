
public class Test_Date {

	public static void main(String[] args) {
	
	int month = 6;
	int day = 6;
	int year = 2006;
	
	Date d1 = new Date(month, day, year);
	Date d2 = new Date(d1.month(), d1.day(), d1.year());
//	System.out.println(x);
	d2.write();

		
	}

}