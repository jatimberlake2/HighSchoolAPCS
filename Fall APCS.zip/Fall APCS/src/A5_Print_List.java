import java.util.*;
public class A5_Print_List {
		public static void main(String[] args) {
			int list_count = 0;
			Scanner derp = new Scanner(System.in);
			String [] names = {"Tim","Bill","Jim","Sue"};
			int head_of_list = 1; // Bill is the first name
			int second_head = 0;
			int current = 0;
			int [] links = {-1,2,3,0}; // shows the next place ending with -1
			boolean spacing = false;
			
			
			
			
		while (true){
			if (spacing == true)
				System.out.println();
			System.out.println("Enter a name.");
			spacing = true;
			
			String nxt = derp.nextLine();
			list_count++;
			String [] names2 = new String[names.length+list_count];	
			names2[names.length] = nxt;	
			int [] links2 = new int[links.length+list_count];
			

			while (current != -1) {	
				second_head = head_of_list;
				current = head_of_list;
				names2[current] = nxt;
				//System.out.println(current);
			if (nxt.compareTo(names[current]) > 0){
 				links2[links2.length - 1] = second_head;
				links2[second_head] = links2.length - 1;
	

			}
			
			  else {
				head_of_list = names.length;
				links2[links.length] = second_head;
			  }
			current = links2[current];
			second_head = current;
			}
		for (int n = 0; n < names.length; n++){
				names2[n] = names[n];	
				links2[n] = links[n];
			}
			names = names2;
			links = links2;
			System.out.println();
			print_names(names, head_of_list, links);
					
					
				}
		}

	public static void print_names (String[] first_names, int head, int[] linked_list){
		while (head != -1){	

			System.out.println(first_names[head]);
			head = linked_list[head];
							}		
			
		
			}
	}