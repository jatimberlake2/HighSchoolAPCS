
public class ThirteenPaperThing {

	public static void main(String[] args) {
		int value;
		final int SENTINEL = -999;
		//while (value != SENTINEL)
		{
			//code to process value
			
			
			//value = IO.readInt();   //read user input
		}

	}

}
