
public class ThreePaperThing {

	public static void main(String[] args) {
 double answer =  13.0/5.0;
 System.out.println("13/5 = " + answer);

	}

}
