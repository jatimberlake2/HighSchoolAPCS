
public class OnePaperThing {

	public static void main(String[] args) {
//double x = 14.7;
//int y = x;

double z = 14.7;
int a = (int) z;

int b = 14;
double c = b;

	}

}
