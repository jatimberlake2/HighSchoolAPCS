
public class Date {

	private int myDay;
	private int myMonth;
	private int myYear;
	
	public Date()
	{
		myDay = 0;
		myMonth = 0;
		myYear = 0;
	}
	public Date(int mo, int day, int yr) //constructor
	{
		myDay = day;
		myMonth = mo;
		myYear = yr;
	}
	public int month() //returns month of Date
	{
		return myMonth;
	}
	public int day() //returns day of Date
	{
		return myDay;
	}
	public int year() //returns year of Date
	{
		return myYear;
	}
	
	//Returns String representation of Date as "m/d/y", e.g. 4/18/1985.
	public String toString()
	{
		String s = (myMonth + "/" + myDay + "/" + myYear);
		return s;
	}
	//Write the data in the form m/d/y, for example 2/17/1948.
	public void write() {
	//	System.out.println(myMonth + "/" + myDay + "/" + myYear);
		System.out.println(month() + "/" + day() + "/" + year());
	//	System.out.println(this);
	}
	public void addYears(int n)		//add n years to date.
	{
		
	}
}
