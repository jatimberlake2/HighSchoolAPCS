public class A3_Print_List {

		
		public static void main(String[] args) {
			String [] names = {"Tim","Bill","Jim","Sue"};
			int head_of_list = 1; // Bill is the first name
			int [] links = {-1,2,3,0}; // shows the next place ending with -1
			print_names(names, head_of_list, links);

		}

		public static void print_names (String[] first_names, int head, int[] linked_list){

while (head != -1){
	System.out.println(first_names[head]);
	head = linked_list[head];
}
				
			}
		}