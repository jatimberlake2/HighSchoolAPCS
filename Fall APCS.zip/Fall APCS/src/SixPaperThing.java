
public class SixPaperThing {

	public static void main(String[] args) {
		int n = 0;
		int x = 52;
		if (n != 0 && x/n > 100)
			System.out.println("Melons!");
		else
			System.out.println("Snails!");

	}

}
