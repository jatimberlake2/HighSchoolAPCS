
public class FourteenPaperThing {

	public static void main(String[] args) {
		

	}

}
