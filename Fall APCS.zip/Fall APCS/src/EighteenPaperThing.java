
public class EighteenPaperThing {

	public static void main(String[] args) {
		//Precodntion: n is a 4-digit integer.
		//Postcondition: Returns true if n is valid, false otherwise.
	int num = 6144;	
	boolean valid = checkNumber(num);
	System.out.println(valid);
	}
		static boolean checkNumber(int n)
		{
			int d1, d2, d3, checkDigit, nRemaining, rem;
			//strip off digits
			checkDigit = n % 10;  		System.out.println(n + " => checkDigit = " + checkDigit);
			nRemaining = n / 10;  		System.out.println(n + " => nRemaining = " + nRemaining);
			d3 = nRemaining % 10; 		System.out.println(n + " => d3 = " + d3);
			nRemaining /= 10;	  		System.out.println(n + " => nRemaining = " + nRemaining);
			d2 = nRemaining % 10; 		System.out.println(n + " => d2 = " + d2);
			nRemaining /= 10;	   		System.out.println(n + " => nRemaining = " + nRemaining);
			d1 = nRemaining % 10; 		System.out.println(n + " => d1 = " + d1);
			//check validity
			rem = (d1 + d2 + d3) % 7;	System.out.println(n + " => (" + d1 + " + " + d2 + " + "+ d3 + ") % 7 = " + rem);
			return rem == checkDigit;
		}

	

}
