import java.util.*;
public class SevenPaperThing {
	public static void main(String[] args) {
		Scanner derp = new Scanner(System.in);
		int num = derp.nextInt();
		if (num > 0)
			if (num % 5 == 0)
				System.out.println(num);
			else
				System.out.println(num + " is negative");
	}

}
