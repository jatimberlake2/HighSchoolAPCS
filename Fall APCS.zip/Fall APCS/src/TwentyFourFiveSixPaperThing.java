
public class TwentyFourFiveSixPaperThing {
	

		private int myHrs;
		private int myMins;
		private int mySecs;
		
		public TwentyFourFiveSixPaperThing()
		{ 
			myHrs = 0;
			myMins = 0;
			mySecs = 0;
		}
		
		public TwentyFourFiveSixPaperThing(int h, int m, int s)
		{ 
			myHrs = h;
			myMins = m;
			mySecs = s;
		}
		
		//Resets TwentyFourFiveSixPaperThing to myHrs = h, myMins = m, mySecs = s.
		public void resetTwentyFourFiveSixPaperThing (int h, int m, int s)
		{	
			myHrs = h;
			myMins = m;
			mySecs = s;
			}
		
		//Advances TwentyFourFiveSixPaperThing by one second.
		public void increment()
		{ /* implementation not shown */ }
		
		//Returns true if this TwentyFourFiveSixPaperThing equals t, false otherwise.
		public boolean equals(TwentyFourFiveSixPaperThing t)
		{
			
			return true;
			}
		
		//Returns true if this TwentyFourFiveSixPaperThing is earlier than t, false otherwise.
		public boolean lessThan(TwentyFourFiveSixPaperThing t)
		{
			
			return false;
			}
		
		//Returns TwentyFourFiveSixPaperThing as a String in the form hrs:mins:secs
		public String toString()
		{
				String dude = (myHrs + ":" + myMins + ":" + mySecs);
				return dude;
		}

		//Outputs TwentyFourFiveSixPaperThing t in the form hrs:mins:secs.
		public void display (TwentyFourFiveSixPaperThing t)
		{
		/*	TwentyFourFiveSixPaperThing T = new TwentyFourFiveSixPaperThing(h,m,s);
			System.out.println(T);  */
			
		System.out.println(t.myHrs + ":" + t.myMins + ":" + t.mySecs); 
			
		System.out.println(t);
			
		}
}
