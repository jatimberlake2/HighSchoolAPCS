
public class NinePaperThing {

	public static void main(String[] args) {
		boolean A = false,B = false,C = false;
		if (!(A && B && C))
			System.out.println("Your mother.");
		else
			System.out.println("c:");
	}

}
