public class A1_Print_List {

		
		public static void main(String[] args) {
			String [] names = {"Tim","Bill","Jim","Sue"};
			print_names(names);

		}
		public static void print_names (String[] first_names){
			for (String n: first_names) 
				System.out.println(n);				
		}

	}
