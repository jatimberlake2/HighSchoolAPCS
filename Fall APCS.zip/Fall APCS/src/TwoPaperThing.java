
public class TwoPaperThing {
	public static void main(String[] args) {
		System.out.println("\\*This is not\n a comment *\\");
	}
}
