
public class FourPaperThing {

	public static void main(String[] args) {
		int result = 13 - 3 * 6 / 4 % 3;
		System.out.println(result);

	}

}
