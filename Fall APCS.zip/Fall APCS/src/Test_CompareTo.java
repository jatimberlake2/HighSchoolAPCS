
public class Test_CompareTo {

	public static void main(String[] args) {
		String gay = "gay";
		String str8 = "straight";
		System.out.println(gay.compareTo(str8));
		if (gay.compareTo(str8) == 0)
			System.out.println("love");
		else
			System.out.println("truth...");
	}

}
