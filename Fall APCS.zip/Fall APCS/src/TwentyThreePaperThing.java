
public class TwentyThreePaperThing {

	public static void main(String[] args) {
		//Precondition: n > 0;
		//Postcondition: returns n with its digits reversed.
		//Example: If n = 234, method reverse returns 432.
		System.out.println(reverse(123456789));
		System.out.println(reverse2(123456789));
		System.out.println(reverse3(123456789));

	}
	
	static int reverse (int n)
		{ 
			int rem, revNum = 0;
			for (int i = 0; i <= n; i++)
			{
				rem = n % 10;
				revNum = revNum * 10 + rem;
				n /= 10;
			}
			return revNum;
		}
	static int reverse2 (int n)
	{ 
		int rem, revNum = 0;
		while (n != 0)
		{
			rem = n% 10;
			revNum = revNum * 10 + rem;
			n /= 10;
		}
		return revNum;
	}
	static int reverse3 (int n)
	{ 
		int rem, revNum = 0;
		for (int i = n; i != 0; i /= 10)
		{
			rem = i % 10;
			revNum = revNum * 10 + rem;
		}
		return revNum;
	}

}
