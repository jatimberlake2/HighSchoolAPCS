public class TenPaperThing {
	public static void main(String[] args) {
		int a = 3, b = 2;
		if (!(a <= b) && (a * b > 0))
			System.out.println("Jews.");
		else
			System.out.println("Jaws.");
	}
}
