import java.util.*;
public class BirthdayStuff 
{
	public static Date findBirthdate()
	{
		Scanner derp = new Scanner(System.in);
		//something
		System.out.println("Enter birthdate: month, day, year: ");
		int m = derp.nextInt();				//read user input
		int d = derp.nextInt();	
		int y = derp.nextInt();	
		Date birthDate = new Date(m, d, y);			
		
	/*	System.out.println("Enter birthdate: month, day, year: ");
		int birthDate.month() = derp.nextInt();				//read user input
		int birthDate.day() = derp.nextInt();	
		int birthDate.year() = derp.nextInt();	
		Date birthDate = new Date(birthDate.month(), birthDate.day(), birthDate.year());	*/
		
	/*	System.out.println("Enter birthdate: month, day, year: ");
		int birthDate.myMonth = derp.nextInt();				//read user input
		int birthDate.myDay = derp.nextInt();	
		int birthDate.myYear = derp.nextInt();	
		Date birthDate = new Date(birthDate.myMonth, birthDate.myDat, birthDate.myYear);	*/
		
		return birthDate;
	}

	public static void main(String[] args)
	{
		
		Date d = findBirthdate();
		System.out.println();
		System.out.println(d);
		//...

	}

}
