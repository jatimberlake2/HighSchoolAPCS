import java.util.*;
public class A4_Print_List {
		public static void main(String[] args) {
			Scanner derp = new Scanner(System.in);
			String [] names = {"Tim","Bill","Jim","Sue"};
			int head_of_list = 1; // Bill is the first name
			int [] links = {-1,2,3,0}; // shows the next place ending with -1
			System.out.println("Enter a name.");
			String nxt = derp.nextLine();
			String [] names2 = new String[names.length+1];	
			names2[names.length] = nxt;			
			int [] links2 = new int[links.length+1];		
			int second_head = head_of_list;
			head_of_list = names.length;
			links2[links.length] = second_head;
		for (int n = 0; n < names.length; n++){
				names2[n] = names[n];	
				links2[n] = links[n];
			}
			names = names2;
			links = links2;
			print_names(names, head_of_list, links);
		}
		public static void print_names (String[] first_names, int head, int[] linked_list){
			while (head != -1){
				System.out.println(first_names[head]);
				head = linked_list[head];
								}		
				}
		}