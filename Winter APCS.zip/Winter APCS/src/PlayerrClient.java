
public class PlayerrClient {


	public static void main(String[] args) {
	/*	
		Player p1 = new HumanPlayer();
		Player p2 = new ExpertPlayer();
		int x1 = p1.getMove();
		int x2 = p2.getMove();
		
		System.out.println("x1: " + x1 + ", x2: " + x2);
		
		int x;
		Comparable c1 = new ExpertPlayer();
		Comparable c2 = new ExpertPlayer();
		if (c1.compareTo(c2) < 0)
			x = c1.getMove();
		else
			x = c2.getMove();

		System.out.println("c1: " + c1 + ", c2: " + c2);
		
		int xx;
		HumanPlayer h1 = new HumanPlayer();
		HumanPlayer h2 = new HumanPlayer();
		if (h1.compareTo(h2) < 0)
			xx = h1.getMove();
		else
			xx = h2.getMove();
		
		System.out.println("h1: " + h1 + ", h2: " + h2);
		
	*/
	
		//int x;
		
		//ExpertPlayer e1 = new ExpertPlayer(123);
		//ExpertPlayer e2 = new ExpertPlayer(234);
		
		Comparable c1 = new ExpertPlayer(1);
		Comparable c2 = new ExpertPlayer(1);
		if (c1.compareTo(c2) == -1)
			System.out.println("Cheese.");
		else if (c1.compareTo(c2) == 0)
			System.out.println("Carrots.");
		else if (c1.compareTo(c2) == 1)
			System.out.println("Handbags.");

		//System.out.println("c1: " + c1 + ", c2: " + c2);
	}

}
