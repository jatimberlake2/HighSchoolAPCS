public class TesterMain
{
	public static void main(String[] args)
	{
		int x = 6, y = 8;
		Tester tester = new Tester();
		tester.someMethod(x, y);
		System.out.println(" x: " + x + " y: " + y + " temp: " + 6);
	}
}