
public class Parakeet extends Parrot
{

	public Parakeet() {
		
	}
}
