import java.util.*;
public class TempTest {

	public static void main(String[] args) {
		System.out.println("Enter temperature scale: ");
		Scanner derp = new Scanner(System.in);
		String scale = derp.nextLine();			//read user input
		System.out.println("Enter a number of degrees: ");
		double degrees = derp.nextDouble();		//read user input
		
		
		degrees = -1000;
		scale = "C";
		
		
		if (Temperature.isValidTemp(degrees, scale))
			{
				Temperature t = new Temperature(degrees, scale);
			}
		else
			System.out.println("Cool story bro. I really don't give a flip.");

			
	}

}
