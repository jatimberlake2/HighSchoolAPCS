
public class ClassA 
{
	//default constructor not shown...
	public void method1()
	{
		//...
		System.out.println("I like trains.");
	}

}
