
public class Bird 
{

	public Bird() {
		
	}
	
}
