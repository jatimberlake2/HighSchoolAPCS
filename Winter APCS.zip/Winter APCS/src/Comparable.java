
public interface Comparable {
	
	

}
