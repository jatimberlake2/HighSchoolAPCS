
public class ClassB extends ClassA
{
	//default constructor not shown...
	public void method1()
	{
		//different from method1 of ClassA
		System.out.println("I like flying");
	}
	
	public void method2()
	{
		//...
		System.out.println("I like swimming in the ocean.");
	}

}
