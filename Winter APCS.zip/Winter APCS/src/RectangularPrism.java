
public class RectangularPrism extends Solid
{
	private double myLength;
	private double myWidth;
	private double myHeight;
	
	
	public RectangularPrism()
	{
		myLength = 0;
		myWidth = 0;
		myHeight = 0;
	}
	
	public RectangularPrism(String name, double l, double w, double h)
	{
		super(name);
		myLength = l;
		myWidth = w;
		myHeight = h;
	}
	
	public double volume()
	{
		return myLength * myWidth * myHeight;
	}

}
