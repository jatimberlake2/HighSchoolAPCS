
public class SavingsAccount extends BankAccount
{
	private double myInterestRate;
	
	public SavingsAccount()
	{
		super();
		
	}
	
	public SavingsAccount (double balance, double rate)
	{
		super(balance);
		myInterestRate = rate;
	}
	
	public void addInterest()		//Add interest to balance
	{
		System.out.println("I dunno how to add Interest but here it is!");
	}
	
	//add-in
	public double getRate()
	{
		return myInterestRate;
	}
}
