public class HumanPlayer implements Player
{
	private String myName;
	
	public HumanPlayer()
	{
		myName = null;
	}
	
	public HumanPlayer(String name)
	{
		name = myName;
	}
	
	public int getMove() {
		return 0;
	}

	public void updateDisplay() {
		
	}
	
	public String getName()
	{
		return myName;
	}




}
