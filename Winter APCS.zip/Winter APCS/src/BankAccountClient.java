
public class BankAccountClient {

	public static void main(String[] args) {
		BankAccount b = new BankAccount(650);
		SavingsAccount timsSavings = new SavingsAccount(1500, 0.03);
		CheckingAccount daynasChecking = new CheckingAccount(2000);
	
		timsSavings.transfer(daynasChecking, 30);
		
		
		System.out.println("Tim: " + timsSavings.getBalance());
		System.out.println("Dayna: " + daynasChecking.getBalance());
	}

}
