
public interface Computable 
{
	//Return this Object * y.
	Object add(Object y);
	
	//Return this Object - y.
	Object subtract(Object y);
	
	//Return this Object * y.
	Object multiply(Object y);

}
