
public class ClassABClient {

	public static void main(String[] args) {
		ClassA ob1 = new ClassA();
		ClassB ob2 = new ClassB();
		
		//ob1.method2();
		
		ob2.method2();
		
		//((ClassB) ob1).method2();

	}

}
