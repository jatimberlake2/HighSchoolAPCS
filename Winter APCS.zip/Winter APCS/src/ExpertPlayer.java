
public class ExpertPlayer extends HumanPlayer implements Comparable
{
	private int myRating;
	
	public ExpertPlayer()
	{
		myRating = 0;
	}
	
	public ExpertPlayer(int rating)
	{
		myRating = rating;
	}
	
	
	public int compareTo(Object obj)
	{
		ExpertPlayer rhs = (ExpertPlayer) obj;
		if (myRating == rhs.myRating)
			return 0;
		else if (myRating < rhs.myRating)
			return -1;
		else
			return 1;

	/*
		ExpertPlayer rhs = (ExpertPlayer) obj;
		return myRating - rhs.myRating;
	
		
		ExpertPlayer rhs = (ExpertPlayer) obj;
		if (getName().equals(rhs.getName()))
			return 0;
		else if (getName().compareTo(rhs.getName()) < 0)
			return -1;
		else
			return 1;
			
	*/
	}

}
