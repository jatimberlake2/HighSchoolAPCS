
public class IntObject
{
	private int myInt;
	
	public IntObject() 			//default constructor
	{
		myInt = 0;
		}
	public IntObject(int n)		//constructor
	{
		myInt = n;
	}
	public void increment()		//increment by 1
	{
		myInt++;
	}
	
	public int getValue()
	{
		return myInt;
	}
}
