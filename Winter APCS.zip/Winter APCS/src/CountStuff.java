import java.util.*;
public class CountStuff
{
	public static void doSomething()
	{
		int count = 0;
			//...
		//cod to do something - no screen output is produced
		count++;
	}
	public static void main(String[] args) 
	{
		Scanner derp = new Scanner(System.in);
		int count = 0;
		System.out.println("How many iterations?");
		int n = derp.nextInt();			//read user input
		for (int i = 1; i <= n; i++)
		{
			doSomething();
			System.out.println(count);
		}
	}
}
