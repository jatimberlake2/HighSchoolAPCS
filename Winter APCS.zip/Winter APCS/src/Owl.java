
public class Owl extends Bird
{
	public Owl() {
		
	}

}
