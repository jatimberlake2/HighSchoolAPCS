
public class BirdStuff 
{
	public static void printName (Bird b)
	{
		System.out.println(b);
	}
	public static void printBirdCall(Parrot p)
	{
		System.out.println(p);
	}
	//several more Bird methods
	
	public static void main(String[] args)
	{
		Bird bird1 = new Bird();
		Bird bird2 = new Parrot();
		Parrot parrot1 = new Parrot();
		Parrot parrot2 = new Parakeet();
		
		printName(parrot2);
		printBirdCall((Parrot) bird2);

		
	}

}
