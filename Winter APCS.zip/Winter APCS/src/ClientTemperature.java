
public class ClientTemperature {


	public static void main(String[] args) {
		Temperature t1 = new Temperature(40, "C");
		Temperature t2 = t1;
		Temperature t3 = t2.lower(20);
		Temperature t4 = t1.toFahrenheit();
		
		System.out.println( " t1: " + (int)t1.getDegrees() + " , " + t1.getScale());
		System.out.println( " t2: " + (int)t2.getDegrees() + " , " + t2.getScale());
		System.out.println( " t3: " + (int)t3.getDegrees() + " , " + t3.getScale());
		System.out.println( " t4: " + (int)t4.getDegrees() + " , " + t4.getScale());
		System.out.println();
		Temperature t5 = t1.inFahrenheit();
		System.out.println( " t5: " + (int)t5.getDegrees() + " , " + t5.getScale());

	}

}
