
public class Temperature implements Comparable
{
	private String myScale; //valid values are "F" or "C"
	private double myDegrees;
	
	//constructors
	/* default constructor */
	public Temperature() 
	{
		myScale = null;
		myDegrees = 0;
	}
	
	/* constructor with specified degrees and scale */
	public Temperature (double degrees, String scale)
	{
		myScale = scale;
		myDegrees = degrees;		
	}
	
	//accessors
	/* Returns degrees for this temperature. */
	public double getDegrees()
	{
		return myDegrees;
	}
	
	/* Returns scale for this temperature. */
	public String getScale()
	{
		return myScale;
	}
	/* Precondition: 	Temperature is a valid temperature
	 * 					in degrees Celsius.
	 * Postcondition:   an equivalent temperature in degrees
	 * 					Fahrenheit has been returned. Original
	 * 					temperature remains unchanged */
	public Temperature inFahrenheit()
	{
		Temperature result;
		
		
		//result =  new Temperature(myDegrees*1.8 + 32, "F");
		
		result = new Temperature(myDegrees*1.8, "F");
		result = result.raise(32);
		
		return result;
	}
	
	//mutators
	/* Precondition: 	Temperature is a valid temperature
	 * 					in degrees Celsius.
	 * Postcondition:	Returns this temperature, which has been
	 * 					converted to degrees Fahrenheit.	 */
	public Temperature toFahrenheit()
	{
		Temperature tf = new Temperature((myDegrees*1.8) + 32, "F");
		return tf;
	}
	/* Precondition: 	Temperature is a valid temperature
	 * 					in degrees Fahrenheit.
	 * Postcondition:	Returns this temperature, which has been
	 * 					converted to degrees Celsius.	 */
	public Temperature toCelsius()
	{
		Temperature tc = new Temperature((myDegrees - 32)/1.8, "C");
		return tc;
	}
	
	/*Raise this temperature by amt degrees and return it. */
	public Temperature raise(double amt)
	{
		Temperature added = new Temperature(myDegrees + amt, myScale);
		return added;
	}
	
	/*Lower this temperature by amt degrees and return it. */
	public Temperature lower(double amt)
	{
		Temperature lowered = new Temperature(myDegrees - amt, myScale);
		return lowered;
	}
	
	/* Returns true if the number of degrees is valid
	 * temperature in the given scale, false otherwise. */
	public static boolean isValidTemp(double degrees, String scale)
	{
		//Temperature check = new Temperature (degrees, scale);
		//if (check.getDegrees() < -273.15 && check.getScale() == "C" ||
		//	check.getDegrees() < -459.67 && check.getScale() == "F")
		if (degrees < -273.15 && scale == "C" || degrees < -459.67 && scale == "F")
			return false;
		return true;
	}
	
	
	
	//other stuff...
	
}
