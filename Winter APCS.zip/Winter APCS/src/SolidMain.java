
public class SolidMain 
{
	/*Output of Solid s. */
	public static void printVolume(Solid s)
	{
		System.out.println("Volume = " + s.volume() + " cubic units");
	}
	
	public static void main (String[] args)
	{
		Solid sol;
		Solid sph = new Sphere("sphere", 4);
		Solid rec = new RectangularPrism("box", 3, 6, 9);
		int flipCoin = (int) (Math.random() * 2);	//0 or 1
		if (flipCoin == 0)
			sol = sph;
		else
			sol = rec;
		printVolume(sol);
	}

}
