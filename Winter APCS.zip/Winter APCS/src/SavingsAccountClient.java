
public class SavingsAccountClient {

	public static void main(String[] args) {
		SavingsAccount s1 = new SavingsAccount();
		s1.addInterest();
		System.out.println("$" + s1.getBalance());
		s1.deposit(24.70);
		System.out.println("$" + s1.getBalance());
		s1.withdraw(3.14);
		System.out.println("$" + s1.getBalance());
		
		System.out.println();
		SavingsAccount s2 = new SavingsAccount(2.34, 5.0);
		System.out.println("$" + s2.getBalance() + " , " + s2.getRate());
		
		System.out.println();
		CheckingAccount v1 = new CheckingAccount(700.32);
		System.out.println(v1.getBalance());
	}

}
