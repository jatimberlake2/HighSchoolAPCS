
public class CheckingAccountClient {

	public static void main(String[] args) {
		CheckingAccount c1 = new CheckingAccount(3.04);
		c1.withdraw(3.03);
		System.out.println(c1.getBalance());

	}

}
