
public class Tester
{
	public void someMethod(int a, int b)
	{
		int temp = a;	//6
		a = b;			//8
		b = temp;		//6
	}
}
