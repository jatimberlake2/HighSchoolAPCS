
public class ShapeClient {

	public static void main(String[] args) {
		Solid s1, s2, s3, s4;
		//s1 = new Solid("blob");
		s2 = new Sphere("sphere", 3.8);
		s3 = new RectangularPrism("box", 2, 4, 6.5);
		s4 = null;

		//System.out.println(s1.getName());
		System.out.println(s2.getName() + ", " + s2.volume());
		System.out.println(s3.getName() + ", " + s3.volume());
		//System.out.println(s4.getName());
	}

}
