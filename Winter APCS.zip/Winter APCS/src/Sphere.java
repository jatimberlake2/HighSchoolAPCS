
public class Sphere extends Solid
{
	private double myRadius;
	
	public Sphere()
	{;
		myRadius = 0;
	}
	public Sphere(String name, double radius)
	{
		super(name);
		myRadius = radius;
	}
	
	public double volume()
	{
		return (4.0/3.0)*Math.PI * myRadius * myRadius * myRadius;
	}

}
