
public class BankAccount
{
	private double myBalance;
	
	public BankAccount()
	{
		myBalance = 0;
	}
	
	public BankAccount (double balance)
	{
		myBalance = balance;
	}
	
	public void deposit (double amount)
	{
		myBalance += amount;
	}
	
	public void withdraw (double amount)
	{
		myBalance -= amount;
	}
	
	public double getBalance()
	{
		return myBalance;
	}
	
	//added in
	
	/*public void setBalance(double balance)
	{
		myBalance = balance;
	}
	*/
	
	/*Transfer amount from this BankAccount to another BankAccount.
	 * Precondition: myBalance > amount */
	
	public void transfer(BankAccount another, double amount)
	{
		withdraw(amount);
		another.deposit(amount);
	}
	
}
