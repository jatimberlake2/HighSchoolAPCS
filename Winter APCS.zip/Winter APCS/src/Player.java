
public interface Player 
{
	/* Return an integer that represents a move in a game. */
	int getMove();
	/* Display an integer of the game for this Player after
	 *  implementing the next move. */
	void updateDisplay();

}
