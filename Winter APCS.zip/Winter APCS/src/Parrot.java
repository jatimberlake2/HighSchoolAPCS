
public class Parrot extends Bird
{
	public Parrot() {
		
	}

}
