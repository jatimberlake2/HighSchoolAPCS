import java.util.*;
public class _1_FindAName {

	public static void main(String[] args) {
		Scanner derp = new Scanner(System.in);
		System.out.println("Who are you looking for?");
		String find = derp.next();
		ArrayList<String> SendNames = new ArrayList<String>();
		SendNames.add("Bob");
		SendNames.add("Aen");
		SendNames.add("Drew");
		SendNames.add("Zoey");
		SendNames.add("Clyde");
		
		System.out.println(DoIt(SendNames, find));

	}
	public static int DoIt(ArrayList<String> names, String findthis){
		
		for (int i = 0; i < names.size(); i++){
			if (names.get(i).equals(findthis))
				return i;
		
		}
		return -1;
		
	}

}
