import java.util.*;
public class _2_FindABinaryName {

	public static void main(String[] args) {
		Scanner derp = new Scanner(System.in);
		System.out.println("Who are you looking for?");
		String find = derp.next();

		ArrayList<String> SendNames = new ArrayList<String>();
		SendNames.add("Aen");
		SendNames.add("Bob");
		SendNames.add("Brett");
		SendNames.add("Clyde");
		SendNames.add("Drew");

		int ret = BinaryIt(SendNames, find);
		
		if (ret >= 0)
			System.out.println(find+ " is located in position # " +ret+ ".");
		else
			System.out.println("That person isn't here. " + ret);
	}
	
	public static int DoIt(ArrayList<String> names, String findthis){
		
		for (int i = 0; i < names.size(); i++){
			if (names.get(i).equals(findthis))
				return i;
		
		}
		return -1;
		
	}
	
	
	public static int BinaryIt(ArrayList<String> names, String findthis){
		
		int right = names.size()-1, left = 0, place = -1;
		boolean found = false;		
		
		//System.out.println(right);
		while (right >= left) {
			int middle = (left + right)/2;				
				if (findthis.equals(names.get(middle))) {
					found = true;
					place = middle;
					break;
				}
				else
					if (findthis.compareTo(names.get(middle)) > 0)
					{
						left = middle + 1;
						}
					else
						right = middle - 1;
		
		}
		if (found)
			return place;
		return -1;
		
	}

}
