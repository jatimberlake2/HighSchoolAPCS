import java.util.*;
public class _6_RecursiveBinaryNames {

	public static void main(String[] args) {
	Scanner derp = new Scanner(System.in);
	System.out.println("Who are you looking for?");
	String find = derp.next();
	ArrayList<String> SendNames = new ArrayList<String>();
	
	SendNames.add("Aen");
	SendNames.add("Bob");
	SendNames.add("Brett");
	SendNames.add("Clyde");
	SendNames.add("Drew");
	int right = SendNames.size(), left = 0;
	System.out.println(BinaryRecursivateIt(SendNames, find, left, right));
}
	
	private static int DoIt(ArrayList<String> names, String findthis){
		
		for (int i = 0; i < names.size(); i++){
			if (names.get(i).equals(findthis))
				return i;
		
		}
		return -1;
		
	}
	
	private static int BinaryIt(ArrayList<String> names, String findthis){
		int right = names.size()-1, left = 0, place = -1;
		boolean found = false;		
		//System.out.println(right);
		while (right >= left) {
			int middle = (left + right)/2;				
				if (findthis.equals(names.get(middle))) {
					found = true;
					place = middle;
					break;
				}
				else
					if (findthis.compareTo(names.get(middle)) > 0)
					{
						left = middle + 1;
						}
					else
						right = middle - 1;
		}

			return place;

	}
	
	private static ArrayList<String> SortIt(ArrayList<String> names){
		String store = "";
		int nextsmall = 0;
		
		for (int i = 0; i < names.size(); i++){
			store = names.get(i);
			for (int j = i; j < names.size(); j++){
				if(names.get(j).compareTo(store) <= 0) { 
					//String t = names.get(i);
					//names.set(i, names.get(j));
					//names.set(j,t);
					
					store = names.get(j);
					nextsmall = j;

				}
				
			}
		names.set(nextsmall, names.get(i));
		names.set(i, store);

		System.out.println(names);
		}
		System.out.println();
		return names;
	}

	private static ArrayList<String> InsertIt(ArrayList<String> names){
		
		for (int i = 1; i < names.size(); i++){
	         String search = names.get(i); 
	         int j = i;
			while (j > 0 && names.get(j - 1).compareTo(search) > 0){
				names.set(j, names.get(j - 1));
				j--;
				
			}
			names.set(j, search);

		}
		return names;
	}
	
	private static int SequenceIt(ArrayList<String> names, String findthis){
		
			if (names.size() == 0)
				return -1;
			if (names.get(names.size()-1).equals(findthis))
				return names.indexOf(findthis);
			names.remove(names.size()-1);
			return SequenceIt(names, findthis);
	}

	private static int BinaryRecursivateIt(ArrayList<String> names, String findthis, int left, int right){
		//boolean found = false;		
			int middle = left + (right-left)/2;
			if (middle == names.size() || middle == -1)
				return -1;
			System.out.println(left + " " + middle + " " + right);
			if (names.get(middle).equals(findthis))
				return middle;
			if (names.get(middle).compareTo(findthis) < 0)
			{		
				left = middle + 1;
				return BinaryRecursivateIt(names, findthis, left, right);
			}
			else //if (names.get(middle).compareTo(findthis) > 0)
			{
				right = middle;
				return BinaryRecursivateIt(names, findthis, left, right);
			}
	}
}

