import java.util.*;
public class _3_SortNames {

	public static void main(String[] args) {

		ArrayList<String> SendNames = new ArrayList<String>();
		SendNames.add("Clyde");
		SendNames.add("Drew");
		SendNames.add("Aen");
		SendNames.add("Brett");
		SendNames.add("Bob");
		
		System.out.println(SortIt(SendNames));
		
	}
	
	public static int DoIt(ArrayList<String> names, String findthis){
		
		for (int i = 0; i < names.size(); i++){
			if (names.get(i).equals(findthis))
				return i;
		
		}
		return -1;
		
	}
	
	public static int BinaryIt(ArrayList<String> names, String findthis){
		
		int right = names.size()-1, left = 0, place = -1;
		boolean found = false;		
		
		//System.out.println(right);
		while (right >= left) {
			int middle = (left + right)/2;				
				if (findthis.equals(names.get(middle))) {
					found = true;
					place = middle;
					break;
				}
				else
					if (findthis.compareTo(names.get(middle)) > 0)
					{
						left = middle + 1;
						}
					else
						right = middle - 1;
		
		}
		if (found)
			return place;
		return -1;
		
	}
	
	public static ArrayList<String> SortIt(ArrayList<String> names){
		String store = "";
		int nextsmall = 0;
		
		for (int i = 0; i < names.size(); i++){
			store = names.get(i);
			for (int j = i; j < names.size(); j++){
				if(names.get(j).compareTo(store) <= 0) { 
					//String t = names.get(i);
					//names.set(i, names.get(j));
					//names.set(j,t);
					
					store = names.get(j);
					nextsmall = j;

				}
				
			}
		names.set(nextsmall, names.get(i));
		names.set(i, store);

		System.out.println(names);
		}
		System.out.println();
		return names;
	}

}

