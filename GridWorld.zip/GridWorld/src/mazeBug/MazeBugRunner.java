package mazeBug;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

import java.awt.Color;
import java.awt.color.*;

public class MazeBugRunner
{
	public static void main(String[] args)
	{
		ActorWorld world = new ActorWorld(new BoundedGrid(6,8));
		mazeBug alice = new mazeBug();
		alice.setDirection(0);
		alice.setColor(Color.ORANGE);
		world.add(new Location (5,1), alice);
		world.add(new Location (1,0), new Rock());
		world.add(new Location (2,0), new Rock());
		world.add(new Location (3,0), new Rock());
		world.add(new Location (4,0), new Rock());
		world.add(new Location (5,0), new Rock());
		world.add(new Location (0,0), new Rock());
		world.add(new Location (0,2), new Rock());
		world.add(new Location (0,3), new Rock());
		world.add(new Location (0,4), new Rock());
		world.add(new Location (0,5), new Rock());
		world.add(new Location (0,6), new Rock());
		world.add(new Location (2,5), new Rock());
		world.add(new Location (3,1), new Rock());
		world.add(new Location (3,2), new Rock());
		world.add(new Location (3,3), new Rock());
		world.add(new Location (3,4), new Rock());
		world.add(new Location (1,7), new Rock());
		world.add(new Location (2,7), new Rock());
		world.add(new Location (3,7), new Rock());
		world.add(new Location (4,7), new Rock());
		world.add(new Location (5,3), new Rock());
		world.add(new Location (5,4), new Rock());
		world.add(new Location (5,5), new Rock());
		world.add(new Location (5,6), new Rock());
		world.show();
	}

}
