package mazeBug;

import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.util.ArrayList;

public class mazeBug extends Bug
{
    public mazeBug()
    {

    }

    public boolean isValidGrid()
    {
    	Grid<Actor> gr = getGrid();
    	if (gr == null)
    		return false;
    	ArrayList<Location> spaces = new ArrayList<Location>();
    	spaces = gr.getOccupiedLocations();
    	for (int i = 0; i < spaces.size(); i++)
    	{
    		Actor spot = gr.get(spaces.get(i));
    		if (!(spot instanceof Rock) && !(spot instanceof Flower) && !(spot instanceof mazeBug))
    			return false;
    	}
    			return true;
    }
    
    public void act()
    {
    if (isValidGrid())	
    {
     if (canMoveLeft())
        	moveLeft();
     else
    	super.act();	
     TurnCorrection();
    	}
       }
    
    public void moveLeft()
    {
    	for (int i = 0; i < 6; i++)
    	{
    		turn();
    	}
    	super.move();
    }
    
    public boolean canMoveLeft()
    {
    	 Grid<Actor> gr = getGrid();
         if (gr == null)
             return false;
         Location loc = getLocation();
         Location left = loc.getAdjacentLocation(getDirection() + 270);
         if(!gr.isValid(left))
        	 return false;
         Location BackLeft = loc.getAdjacentLocation(getDirection() + 225);
         Actor neighbor = gr.get(left);
         if ((neighbor instanceof Rock) && !gr.isValid(BackLeft))
             return false;
         Actor neighborBL = gr.get(BackLeft);
         if (!(neighbor instanceof Rock) && (neighborBL instanceof Rock))
        	 return true;
    	return false;
    }

    public void TurnCorrection()
    {
    	if (getDirection() == 45 || getDirection() == 225 || getDirection() == 135 || getDirection() == 315)
    		turn();
    }
}
