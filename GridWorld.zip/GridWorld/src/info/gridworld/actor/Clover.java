package info.gridworld.actor;
import java.awt.Color;

public class Clover extends Flower
{
	public void pollinate()
	{
		setColor(Color.YELLOW);
		//boolean ImPollinatedNow = true;
	}
	
	public boolean hasBeenPollinated()
	{
		if (getColor().equals(Color.YELLOW))
		return true;
	return false;
	}
	
	public void act()
	{
		
	}
	
	
}
