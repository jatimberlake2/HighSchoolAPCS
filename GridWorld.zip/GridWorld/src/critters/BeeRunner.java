package critters;

import info.gridworld.actor.*;
import info.gridworld.grid.Location;

import java.awt.Color;

public class BeeRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        world.add(new Location(0, 1), new Clover());
        world.add(new Location(1, 0), new Clover());
        world.add(new Location(1, 2), new Clover());
        world.add(new Location(2, 1), new Clover());
        world.add(new Location(3, 3), new Clover());

        world.add(new Location(1, 1), new Bee());
        world.show();
    }
}