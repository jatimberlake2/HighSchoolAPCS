package critters;

import info.gridworld.actor.*;
import info.gridworld.grid.Location;

import java.awt.Color;

public class DahliaRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        world.add(new Location(4, 4), new Dahlia());
        world.add(new Location(5, 6), new Dahlia(Color.GREEN));
        world.show();
    }
}