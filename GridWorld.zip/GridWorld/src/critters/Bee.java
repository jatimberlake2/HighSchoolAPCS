package critters;
import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.awt.Color;
import java.util.ArrayList;

public class Bee extends Critter
{
	public Bee()
	{
		setColor(Color.YELLOW);
	}
	
	public void processActors(ArrayList<Actor> actors)
	{
        int n = actors.size();
        if (n == 0)
        	return;
			for (int r = 0; r < n; r++)
			{
			Clover other = (Clover) actors.get(r);
			if (other instanceof Clover && !other.hasBeenPollinated())
				other.pollinate();
			}
	}
	
	public Location selectMoveLocation(ArrayList<Location> locs)
	{
        int n = locs.size();
        Location nextloc = findNearestClover(getLocation());
        if (n == 0 || nextloc == null)
            return getLocation();
        return nextloc;
	}
	
	public void makeMove(Location loc)
	{
	   	Grid<Actor> gr = getGrid();
		Actor spot = gr.get(loc);
		if (!((Clover) spot).hasBeenPollinated())
			setDirection(loc.getDirectionToward(findNearestClover(getLocation())));
		act();
		
		
	}
	
	private int distance(Location loc1, Location loc2)
	{
		return 0;
	}
	
	private Location findNearestClover(Location loc)
	{
	 return loc;	
	}

}
