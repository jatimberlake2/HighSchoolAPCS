package critters;
import java.awt.Color;
import java.util.*;
import info.gridworld.actor.*;
import info.gridworld.grid.*;

public class Dahlia extends Flower
{
	private int weeks;
	private Color crayon;
	
	public Dahlia()
	{
		super();
		crayon = getColor();
		weeks = 0;
	}
	
	public Dahlia(Color col)
	{
		super(col);
		crayon = col;
		weeks = 0;
	}
	
	public void act()
	{
		weeks++;
		if (weeks < 4)
			super.act();
		
		else
		{
			Grid<Actor> gr = getGrid();
			ArrayList<Location> locs = gr.getValidAdjacentLocations(getLocation());
			int n = locs.size();

			for (int i = 0; i < 3; i++)
			{
				Dahlia seed = new Dahlia(crayon);
        		int r = (int) (Math.random() * n);
        		
        		Location loc = locs.get(r);
        		
        		if (gr.get(loc) == null)
        			seed.putSelfInGrid(gr, loc);
			}
			removeSelfFromGrid();
		}
	}	
}