package boxBug;
import info.gridworld.actor.Bug;

public class DancingBug extends Bug
{
    private int turns;
    private int[] total_turns;
    private int number_of_turns;
    private boolean MoveIt;
    private boolean first;
    private int turncount;

    public DancingBug(int[] total)
    {
     turns = total.length;
     total_turns = total;
     number_of_turns = 0;
     MoveIt = false;
     turncount = 0;
     first = true;

    }

    public void act()
    {
        if (canMove() && MoveIt && !first)
        {
            move();
            MoveIt = false;
            
            if (number_of_turns == turns)
            	number_of_turns = 0;
            
        }
        else if (total_turns[number_of_turns] == 0 && canMove())
        {
          	super.move();
          	MoveIt = false;
          	number_of_turns++;
          	turncount = 0;
        }

        
       else if (number_of_turns < turns && !MoveIt)
        {

            
           if  (turncount < total_turns[number_of_turns])
           {
        	turn();
        	turncount++;  	   
           }

            
            if (turncount >= total_turns[number_of_turns])
            {
            	turncount = 0;
            	number_of_turns++;
            	MoveIt = true;
            }
            


            first = false;
        }
       else if(!canMove())
            {
            	turn();
            	turn();
            }
        

    }
}
