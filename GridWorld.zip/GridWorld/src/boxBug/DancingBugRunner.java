package boxBug;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

//import java.awt.Color;

public class DancingBugRunner
{
    public static void main(String[] args)
    {
        //ActorWorld world = new ActorWorld();
        //int [] Turning = {1, 2, 3, 4, 5};
        //BoxBug alice = new BoxBug(6);
        //alice.setColor(Color.ORANGE);
        

          ActorWorld world = new ActorWorld();
          int [] Turning = {0,0};	
          DancingBug bob = new DancingBug(Turning);
          world.add(new Location(5, 3), bob);
          world.show();
        
        //world.add(new Location(7, 8), alice);

    }
}